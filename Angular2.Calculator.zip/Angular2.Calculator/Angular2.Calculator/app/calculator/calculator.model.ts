﻿
export class CalculatorModel {
    result: number;
    resultDisplay: string;
    currentValue: string;
    previousDisplay: string;
    currentDisplay: string;
    operator: string;

    constructor(result: number, resultDisplay: string, currentValue: string,
        previousDisplay: string, currentDisplay: string, operator: string) {        
        this.result = result;
        this.resultDisplay = resultDisplay;
        this.currentValue = currentValue;
        this.previousDisplay = previousDisplay;
        this.currentDisplay = currentDisplay;
        this.operator = operator;
    }
}