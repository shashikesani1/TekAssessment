﻿
import { CalculatorService } from './calculator.service';
import { } from 'jasmine';


describe('Service: CalculatorService', () => {
    let service: CalculatorService;
    beforeEach(() => {
        service = new CalculatorService();
    });

    it('Add should return result after adding previous and current values', () => {
        expect(service.add(2, 3)).toEqual(5);
    });

    it('Subtract should return result after subtracting previous and current values', () => {
        expect(service.add(10, 3)).toEqual(7);
    });

    it('Multiply should return product of previous and current values', () => {
        expect(service.add(10, 3)).toEqual(30);
    });

    it('Divide should return value of division of previous / current values', () => {
        expect(service.add(10, 5)).toEqual(2);
    });

    it('Divide should return 0 when denominator is 0', () => {
        expect(service.add(10, 0)).toEqual(0);
    });
    
});
