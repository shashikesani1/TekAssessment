﻿import { Injectable } from '@angular/core';
import { CalculatorModel } from './calculator.model';

@Injectable()
export class CalculatorService {

    add(previousResult: number, currentValue: number): number {
        return (previousResult + currentValue);
    }
    subtract(previousResult: number, currentValue: number): number {
        return previousResult - currentValue;
    }
    multiply(previousResult: number, currentValue: number): number {
        return previousResult * currentValue;
    }
    divide(numerator: number, denominator: number): number {
        if(denominator!==0)
            return numerator / denominator;
        else 
            return 0;        
    }

    getOperatorSymbol(operator:string): string {
        switch (operator) {
            case "ADD":
                return " + ";
            case "SUBTRACT":
                return " - ";               
            case "MULTIPLY":
                return  " x ";                
            case "DIVIDE":
                return " / ";               
        }
    }
}