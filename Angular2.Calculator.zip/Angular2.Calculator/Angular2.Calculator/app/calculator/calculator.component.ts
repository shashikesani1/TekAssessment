﻿import { Component, Input} from '@angular/core';
import { CalculatorService } from './calculator.service';
import { CalculatorModel} from './calculator.model';

@Component({
    selector: 'calculator',
    templateUrl: './app/calculator/calculator.template.html',
    providers: [CalculatorService]
})
export class CalculatorComponent {

    calculatorService: CalculatorService;
    calculatorModel: CalculatorModel = new CalculatorModel(0, "", "0", " ", "0", "");
    private isOperatorApplied:boolean=false;
    private operatorType: string = "";
    private operatorSymbol: string = "";

    constructor(calculatorService: CalculatorService) {
        this.calculatorService = calculatorService;
    }

    updateSelectedValue(input): void {
        this.isOperatorApplied = false;     
        if (this.calculatorModel.currentValue === "0") {                       
            this.calculatorModel.currentDisplay = "";
        }
        if (this.calculatorModel.currentDisplay.length < 10) {
            this.calculatorModel.currentValue += input;
            this.calculatorModel.currentDisplay += input;
        }
    }

    calculateResult(previousOperator): void {
        switch (previousOperator) {
            case "ADD":              
                this.calculatorModel.result = this.calculatorService
                    .add(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            case "SUBTRACT":                
                this.calculatorModel.result = this.calculatorService
                    .subtract(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            case "MULTIPLY":   
                this.calculatorModel.result = this.calculatorService
                    .multiply(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));             
                break;
            case "DIVIDE": 
                this.calculatorModel.result = this.calculatorService
                    .divide(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));                   
                break;
            default:
                this.calculatorModel.result = parseFloat(this.calculatorModel.currentValue);
                break;                
        }

        if(this.calculatorModel.result.toString().length>10)
            this.calculatorModel.currentDisplay = Math.round(this.calculatorModel.result).toExponential().toString();
        else 
            this.calculatorModel.currentDisplay = this.calculatorModel.result.toString();       
    }

    applyOperator(operator): void {
        if (!this.isOperatorApplied) {           
            this.calculatorModel.previousDisplay += this.calculatorModel.currentDisplay + this.calculatorService.getOperatorSymbol(operator);  
            this.calculateResult(this.operatorType);         
            this.operatorType = operator;
            this.isOperatorApplied = true;
        }
        this.calculatorModel.currentValue = "0";
    }

    clear(): void{
        this.calculatorModel= new CalculatorModel(0, "", "0", " ", "0", "");
    }

    backSpace(): void {
        this.calculatorModel.currentValue = this.calculatorModel.currentValue
            .substr(0, (this.calculatorModel.currentValue.length - 1));
        this.calculatorModel.currentDisplay = this.calculatorModel.currentDisplay
            .substr(0, (this.calculatorModel.currentDisplay.length - 1));

        if (this.calculatorModel.currentDisplay.length === 0) {
            this.calculatorModel.currentDisplay = "0";
            this.calculatorModel.currentValue = "0";
        }
    }

    getResult(): void {           
        this.calculateResult(this.operatorType);
        this.calculatorModel = new CalculatorModel(0, "", "0", " ", this.calculatorModel.currentDisplay, "");       
        this.operatorType = "";          
    }
}