"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var CalculatorService = (function () {
    function CalculatorService() {
    }
    CalculatorService.prototype.add = function (previousResult, currentValue) {
        return (previousResult + currentValue);
    };
    CalculatorService.prototype.subtract = function (previousResult, currentValue) {
        return previousResult - currentValue;
    };
    CalculatorService.prototype.multiply = function (previousResult, currentValue) {
        return previousResult * currentValue;
    };
    CalculatorService.prototype.divide = function (numerator, denominator) {
        if (denominator !== 0)
            return numerator / denominator;
        else
            return 0;
    };
    CalculatorService.prototype.getOperatorSymbol = function (operator) {
        switch (operator) {
            case "ADD":
                return " + ";
            case "SUBTRACT":
                return " - ";
            case "MULTIPLY":
                return " x ";
            case "DIVIDE":
                return " / ";
        }
    };
    CalculatorService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], CalculatorService);
    return CalculatorService;
}());
exports.CalculatorService = CalculatorService;
//# sourceMappingURL=calculator.service.js.map