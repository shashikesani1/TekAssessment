"use strict";
var CalculatorModel = (function () {
    function CalculatorModel(result, resultDisplay, currentValue, previousDisplay, currentDisplay, operator) {
        this.result = result;
        this.resultDisplay = resultDisplay;
        this.currentValue = currentValue;
        this.previousDisplay = previousDisplay;
        this.currentDisplay = currentDisplay;
        this.operator = operator;
    }
    return CalculatorModel;
}());
exports.CalculatorModel = CalculatorModel;
//# sourceMappingURL=calculator.model.js.map