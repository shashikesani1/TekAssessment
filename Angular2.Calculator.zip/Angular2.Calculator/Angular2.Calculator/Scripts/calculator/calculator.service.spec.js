"use strict";
var calculator_service_1 = require('./calculator.service');
describe('Service: CalculatorService', function () {
    var service;
    beforeEach(function () {
        service = new calculator_service_1.CalculatorService();
    });
    it('Add should return result after adding previous and current values', function () {
        expect(service.add(2, 3)).toEqual(5);
    });
    it('Subtract should return result after subtracting previous and current values', function () {
        expect(service.add(10, 3)).toEqual(7);
    });
    it('Multiply should return product of previous and current values', function () {
        expect(service.add(10, 3)).toEqual(30);
    });
    it('Divide should return value of division of previous / current values', function () {
        expect(service.add(10, 5)).toEqual(2);
    });
    it('Divide should return 0 when denominator is 0', function () {
        expect(service.add(10, 0)).toEqual(0);
    });
});
//# sourceMappingURL=calculator.service.spec.js.map