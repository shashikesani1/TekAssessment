"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var calculator_service_1 = require('./calculator.service');
var calculator_model_1 = require('./calculator.model');
var CalculatorComponent = (function () {
    function CalculatorComponent(calculatorService) {
        this.calculatorModel = new calculator_model_1.CalculatorModel(0, "", "0", " ", "0", "");
        this.isOperatorApplied = false;
        this.operatorType = "";
        this.operatorSymbol = "";
        this.calculatorService = calculatorService;
    }
    CalculatorComponent.prototype.updateSelectedValue = function (input) {
        this.isOperatorApplied = false;
        if (this.calculatorModel.currentValue === "0") {
            this.calculatorModel.currentDisplay = "";
        }
        if (this.calculatorModel.currentDisplay.length < 10) {
            this.calculatorModel.currentValue += input;
            this.calculatorModel.currentDisplay += input;
        }
    };
    CalculatorComponent.prototype.calculateResult = function (previousOperator) {
        switch (previousOperator) {
            case "ADD":
                this.calculatorModel.result = this.calculatorService
                    .add(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            case "SUBTRACT":
                this.calculatorModel.result = this.calculatorService
                    .subtract(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            case "MULTIPLY":
                this.calculatorModel.result = this.calculatorService
                    .multiply(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            case "DIVIDE":
                this.calculatorModel.result = this.calculatorService
                    .divide(this.calculatorModel.result, parseFloat(this.calculatorModel.currentValue));
                break;
            default:
                this.calculatorModel.result = parseFloat(this.calculatorModel.currentValue);
                break;
        }
        if (this.calculatorModel.result.toString().length > 10)
            this.calculatorModel.currentDisplay = Math.round(this.calculatorModel.result).toExponential().toString();
        else
            this.calculatorModel.currentDisplay = this.calculatorModel.result.toString();
    };
    CalculatorComponent.prototype.applyOperator = function (operator) {
        if (!this.isOperatorApplied) {
            this.calculatorModel.previousDisplay += this.calculatorModel.currentDisplay + this.calculatorService.getOperatorSymbol(operator);
            this.calculateResult(this.operatorType);
            this.operatorType = operator;
            this.isOperatorApplied = true;
        }
        this.calculatorModel.currentValue = "0";
    };
    CalculatorComponent.prototype.clear = function () {
        this.calculatorModel = new calculator_model_1.CalculatorModel(0, "", "0", " ", "0", "");
    };
    CalculatorComponent.prototype.backSpace = function () {
        this.calculatorModel.currentValue = this.calculatorModel.currentValue
            .substr(0, (this.calculatorModel.currentValue.length - 1));
        this.calculatorModel.currentDisplay = this.calculatorModel.currentDisplay
            .substr(0, (this.calculatorModel.currentDisplay.length - 1));
        if (this.calculatorModel.currentDisplay.length === 0) {
            this.calculatorModel.currentDisplay = "0";
            this.calculatorModel.currentValue = "0";
        }
    };
    CalculatorComponent.prototype.getResult = function () {
        this.calculateResult(this.operatorType);
        this.calculatorModel = new calculator_model_1.CalculatorModel(0, "", "0", " ", this.calculatorModel.currentDisplay, "");
        this.operatorType = "";
    };
    CalculatorComponent = __decorate([
        core_1.Component({
            selector: 'calculator',
            templateUrl: './app/calculator/calculator.template.html',
            providers: [calculator_service_1.CalculatorService]
        }), 
        __metadata('design:paramtypes', [calculator_service_1.CalculatorService])
    ], CalculatorComponent);
    return CalculatorComponent;
}());
exports.CalculatorComponent = CalculatorComponent;
//# sourceMappingURL=calculator.component.js.map